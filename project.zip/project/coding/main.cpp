#include <SFML/Graphics.hpp>
#include <vector>
#include <iostream>

const int thickness = 70;
const int separation = 30;

class ArrayVisualizer {
private:
    std::vector<int> arr;
    sf::RenderWindow window;
    int windowWidth;
    int windowHeight;
    float barWidth;

public:
    int getMax()
    {
    int max = arr[0];
    for (int i = 1; i < arr.size(); i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max;
    }

    ArrayVisualizer(std::vector<int> array) : arr(array) {
        windowWidth = arr.size() * (thickness + separation) + 400; // Set your desired window width
        windowHeight = getMax()* 20 + 200; // Set your desired window height
        barWidth = windowWidth / static_cast<float>(arr.size());
        window.setPosition(sf::Vector2i(1200, 1200));
        window.create(sf::VideoMode(windowWidth, windowHeight), "Insertion Sort Visualization");

    }

    void drawArray() {
        window.clear();
        for (size_t i = 0; i < arr.size(); i++) {
            sf::RectangleShape bar(sf::Vector2f(thickness, arr[i] * 20));
            bar.setPosition(200 + (thickness + separation) * i, 250 - arr[i] * 20);
            bar.setFillColor(sf::Color::Red); // Set the color of the bar
            window.draw(bar);

            sf::Text numText;
            sf::Font font;
            font.loadFromFile("arial.ttf");
            numText.setFont(font);
            // Set up your text properties (font, size, color) here
            numText.setCharacterSize(15);
            numText.setFillColor(sf::Color::White);
            numText.setString(std::to_string(arr[i]));
            numText.setPosition(i * barWidth, windowHeight - bar.getSize().y - 20); // Adjust position as needed
            sf::FloatRect textBounds = numText.getLocalBounds();
            numText.setPosition(bar.getPosition().x, 260);
        }
        window.display();
    }

    void insertionSort() {
        for (size_t i = 1; i < arr.size(); i++) {
            int key = arr[i];
            int j = i - 1;

                drawArray(); // Draw the array for each iteration
                waitForEnter(); // Wait for user to press Enter
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j = j - 1;
                drawArray(); // Draw the array for each iteration
                waitForEnter(); 
            }
            arr[j + 1] = key;
        }
    }

    void waitForEnter() {
        std::cout << "Press Enter to continue...";
        std::cin.ignore();
    }

    void run() {
        while (window.isOpen()) {
            sf::Event event;
            while (window.pollEvent(event)) {
                if (event.type == sf::Event::Closed)
                    window.close();
            }
            insertionSort();
        }
    }
};

int main() {
    
    std::vector<int> myArray = {5, 3, 8, 6, 2, 7, 4, 1};
    ArrayVisualizer visualizer(myArray);
    visualizer.run();

    // Your code to get the array from the user goes here

    return 0;
}
